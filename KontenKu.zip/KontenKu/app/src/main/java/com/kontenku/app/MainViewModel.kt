package com.kontenku.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kontenku.app.data.AppDatabase
import com.kontenku.app.data.Article
import com.kontenku.app.data.Comment
import com.kontenku.app.data.Idea
import com.kontenku.app.data.Post
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()

    val ideas = dao.ideas()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val articles = dao.articles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val posts = dao.posts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val comments = dao.comments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            if (dao.articleCount() == 0) dao.insertArticles(seedArticles)
        }
    }

    // Perencana
    fun saveIdea(idea: Idea) = viewModelScope.launch { dao.upsertIdea(idea) }
    fun deleteIdea(idea: Idea) = viewModelScope.launch { dao.deleteIdea(idea) }

    // Pustaka
    fun saveArticle(article: Article) = viewModelScope.launch { dao.upsertArticle(article) }
    fun deleteArticle(article: Article) = viewModelScope.launch { dao.deleteArticle(article) }
    fun toggleBookmark(article: Article) =
        saveArticle(article.copy(bookmarked = !article.bookmarked))

    // Feed
    fun addPost(text: String) = viewModelScope.launch { dao.upsertPost(Post(text = text)) }
    fun deletePost(post: Post) = viewModelScope.launch {
        dao.deleteComments(post.id)
        dao.deletePost(post)
    }
    fun toggleLike(post: Post) = viewModelScope.launch {
        val nowLiked = !post.liked
        dao.upsertPost(
            post.copy(liked = nowLiked, likes = (post.likes + if (nowLiked) 1 else -1).coerceAtLeast(0))
        )
    }
    fun addComment(postId: Long, text: String) =
        viewModelScope.launch { dao.insertComment(Comment(postId = postId, text = text)) }

    private val seedArticles = listOf(
        Article(
            title = "5 Detik Pertama: Kunci Hook yang Menahan Penonton",
            category = "Tips Video",
            body = "Penonton memutuskan lanjut atau tidak dalam beberapa detik pertama. " +
                "Mulai dari bagian paling menarik atau pertanyaan yang memancing rasa penasaran, " +
                "bukan dari perkenalan panjang.\n\n" +
                "Coba tiga pola: (1) hasil akhir dulu, baru prosesnya; (2) pertanyaan yang dekat " +
                "dengan masalah penonton; (3) pernyataan yang berlawanan dengan anggapan umum."
        ),
        Article(
            title = "Menyusun Kalender Konten Mingguan yang Realistis",
            category = "Perencanaan",
            body = "Konsistensi lebih penting daripada jumlah. Tentukan berapa konten yang sanggup " +
                "kamu buat per minggu, lalu kelompokkan pekerjaannya: hari riset dan naskah, " +
                "hari syuting, hari edit, hari upload.\n\n" +
                "Menyiapkan beberapa konten sekaligus (batching) menghemat waktu dan menjaga " +
                "jadwal tetap jalan saat kamu sedang sibuk."
        ),
        Article(
            title = "Storytelling Sederhana: Awal, Konflik, Penyelesaian",
            category = "Naskah",
            body = "Cerita yang baik tidak harus rumit. Kenalkan situasi, munculkan masalah atau " +
                "halangan, lalu tunjukkan bagaimana masalah itu diselesaikan.\n\n" +
                "Tambahkan detail kecil yang spesifik (tempat, waktu, perasaan) supaya penonton " +
                "bisa membayangkan dan merasa dekat dengan ceritamu."
        )
    )
}
