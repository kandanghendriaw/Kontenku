package com.kontenku.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface ContentDao {
    @Query("SELECT * FROM ideas ORDER BY createdAt DESC")
    fun ideas(): Flow<List<Idea>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertIdea(idea: Idea)

    @Delete
    suspend fun deleteIdea(idea: Idea)

    @Query("SELECT * FROM articles ORDER BY id")
    fun articles(): Flow<List<Article>>

    @Query("SELECT COUNT(*) FROM articles")
    suspend fun articleCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertArticle(article: Article)

    @Insert
    suspend fun insertArticles(list: List<Article>)

    @Delete
    suspend fun deleteArticle(article: Article)

    @Query("SELECT * FROM posts ORDER BY createdAt DESC")
    fun posts(): Flow<List<Post>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPost(post: Post)

    @Delete
    suspend fun deletePost(post: Post)

    @Query("SELECT * FROM comments ORDER BY id")
    fun comments(): Flow<List<Comment>>

    @Insert
    suspend fun insertComment(comment: Comment)

    @Query("DELETE FROM comments WHERE postId = :postId")
    suspend fun deleteComments(postId: Long)
}

@Database(
    entities = [Idea::class, Article::class, Post::class, Comment::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): ContentDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "kontenku.db"
            ).build().also { instance = it }
        }
    }
}
