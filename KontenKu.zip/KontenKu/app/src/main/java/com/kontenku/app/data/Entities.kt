package com.kontenku.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

val PLATFORMS = listOf("YouTube", "TikTok", "Instagram", "Facebook")
val STATUSES = listOf("Ide", "Syuting", "Edit", "Upload")

@Entity(tableName = "ideas")
data class Idea(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val platform: String = PLATFORMS.first(),
    val status: String = STATUSES.first(),
    val script: String = "",
    val footage: String = "",
    val schedule: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "articles")
data class Article(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String,
    val body: String,
    val bookmarked: Boolean = false
)

@Entity(tableName = "posts")
data class Post(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val likes: Int = 0,
    val liked: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "comments")
data class Comment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val postId: Long,
    val text: String
)
