package com.kontenku.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kontenku.app.MainViewModel
import com.kontenku.app.data.Idea
import com.kontenku.app.data.PLATFORMS
import com.kontenku.app.data.STATUSES

@Composable
fun PlannerScreen(vm: MainViewModel, modifier: Modifier = Modifier) {
    val ideas by vm.ideas.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<Idea?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf<String?>(null) }

    val shown = if (filter == null) ideas else ideas.filter { it.status == filter }

    Box(modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Text(
                "Perencana Konten",
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.padding(16.dp)
            )
            Row(
                Modifier
                    .horizontalScrollCompat()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = filter == null,
                    onClick = { filter = null },
                    label = { Text("Semua") }
                )
                STATUSES.forEach { s ->
                    FilterChip(
                        selected = filter == s,
                        onClick = { filter = if (filter == s) null else s },
                        label = { Text(s) }
                    )
                }
            }
            if (shown.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Belum ada ide. Tekan tombol + untuk menambah.")
                }
            } else {
                LazyColumn(
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                        start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(shown, key = { it.id }) { idea ->
                        IdeaCard(idea) {
                            editing = idea
                            showDialog = true
                        }
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { editing = null; showDialog = true },
            icon = { Icon(Icons.Default.Add, contentDescription = null) },
            text = { Text("Ide baru") },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        )
    }

    if (showDialog) {
        IdeaDialog(
            initial = editing,
            onDismiss = { showDialog = false },
            onSave = { vm.saveIdea(it); showDialog = false },
            onDelete = { idea -> vm.deleteIdea(idea); showDialog = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IdeaCard(idea: Idea, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(idea.title, style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = onClick, label = { Text(idea.platform) })
                AssistChip(onClick = onClick, label = { Text(idea.status) })
            }
            if (idea.schedule.isNotBlank()) {
                Text("Jadwal: ${idea.schedule}", style = MaterialTheme.typography.bodySmall)
            }
            if (idea.footage.isNotBlank()) {
                Text(
                    "Footage: ${idea.footage}",
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2
                )
            }
        }
    }
}

@Composable
private fun IdeaDialog(
    initial: Idea?,
    onDismiss: () -> Unit,
    onSave: (Idea) -> Unit,
    onDelete: (Idea) -> Unit
) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var platform by remember { mutableStateOf(initial?.platform ?: PLATFORMS.first()) }
    var status by remember { mutableStateOf(initial?.status ?: STATUSES.first()) }
    var schedule by remember { mutableStateOf(initial?.schedule ?: "") }
    var script by remember { mutableStateOf(initial?.script ?: "") }
    var footage by remember { mutableStateOf(initial?.footage ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Ide baru" else "Edit ide") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text("Judul") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Platform", style = MaterialTheme.typography.labelMedium)
                Row(Modifier.horizontalScrollCompat(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PLATFORMS.forEach {
                        FilterChip(selected = platform == it, onClick = { platform = it }, label = { Text(it) })
                    }
                }
                Text("Status", style = MaterialTheme.typography.labelMedium)
                Row(Modifier.horizontalScrollCompat(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    STATUSES.forEach {
                        FilterChip(selected = status == it, onClick = { status = it }, label = { Text(it) })
                    }
                }
                OutlinedTextField(
                    value = schedule, onValueChange = { schedule = it },
                    label = { Text("Jadwal posting (mis. 25 Nov, 19.00)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = script, onValueChange = { script = it },
                    label = { Text("Script / naskah") }, minLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = footage, onValueChange = { footage = it },
                    label = { Text("Daftar footage") }, minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank(),
                onClick = {
                    val base = initial ?: Idea(title = title)
                    onSave(
                        base.copy(
                            title = title.trim(), platform = platform, status = status,
                            schedule = schedule.trim(), script = script, footage = footage
                        )
                    )
                }
            ) { Text("Simpan") }
        },
        dismissButton = {
            Row {
                if (initial != null) TextButton(onClick = { onDelete(initial) }) { Text("Hapus") }
                TextButton(onClick = onDismiss) { Text("Batal") }
            }
        }
    )
}

@Composable
internal fun Modifier.horizontalScrollCompat(): Modifier =
    this.then(Modifier.horizontalScroll(rememberScrollState()))
